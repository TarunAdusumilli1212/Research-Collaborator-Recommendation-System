For Node2Vec download from release
or else open with colab link https://colab.research.google.com/drive/12VnahRMfnzx4QGhdvZAV9JcXgEHZ6xnw?usp=sharing
